# Todo API

This project is a Serverless application that provides a RESTful API for managing a todo list.

## Setup

1. Install the Serverless Framework:

   npm install -g serverless
Install project dependencies:

npm install

Deploy the service to AWS:

serverless deploy

To run the service locally:

serverless offline
Endpoints
POST /todos - Create a new todo item
GET /todos - Retrieve all todo items
PUT /todos/{id} - Update a todo item
DELETE /todos/{id} - Delete a todo item (only if completed)

Testing
Unit tests are provided using Jest. To run the tests:

npm test


Requirements
Node.js
Serverless Framework
AWS account