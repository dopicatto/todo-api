// __mocks__/uuid.js
module.exports = {
  v4: jest.fn(() => '1234'),
};
